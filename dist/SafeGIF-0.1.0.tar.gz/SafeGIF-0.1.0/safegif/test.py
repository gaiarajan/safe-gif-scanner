import processFrames

filename = input("input gif filename: ")
print(processFrames.process_gif(filename))
